<?php

get_header();
?>

<div class="blog">

	<div id="primary" class="content-area">
		<main id="main" class="site-main">
			<div class="container">
				<div class="row">

					<?php
					if (have_posts()) :
						while (have_posts()) :
							the_post();
							?>
							<div class="col-sm-4 article-container">
								<?php
								get_template_part('template-parts/content', get_post_type());
								?>
							</div>
						<?php
						endwhile;

						echo "<div class='col-12 pagination'><div>";
                        echo paginate_links();
                        echo "</div></div>";

					else : get_template_part('template-parts/content', 'none');
					endif;
					?>
				</div>
			</div>
		</main>
	</div>
</div>

<?php

get_footer();
?>