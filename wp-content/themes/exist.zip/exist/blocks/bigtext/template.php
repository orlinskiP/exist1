<section id="block_bigtext" data-aos="fade-right" data-aos-duration="1000">
    <div class="container <?php the_field('textFormat') ?>">
        <div class="bigText">
            <p class="bigText__text"><?php the_field('text') ?></p>
        </div>
    </div>

</section>