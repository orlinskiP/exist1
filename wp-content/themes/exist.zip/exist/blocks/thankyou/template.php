<section id="block_thankyou">
			
<div class="container text-center error">
                    <h2 class="error__header">Dziękujemy za kontakt.</h2>
                    <p class="error__text">Wyceny dokonamy w ciągu 24 godzin</p>
					<p class="error__text">później skontaktujemy się z Tobą!</p>
                    <div class="error__button">
                        <div class="error__button-first">
                            <a href="<?= site_url(); ?>">Powrót do strony głównej</a>
                        </div>
                    </div>
                </div>

</section>