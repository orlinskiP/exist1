<section id="block_footer">

    <div class="container">

        <div class="footer">
            <div class="footer__contact">
                <div>
                    <a class="footer__number" href="tel: 665631912">Szymon: 665-631-912</a>
                </div>
                <div>
                    <a class="footer__number" href="tel: 731620641">Patryk: 731-620-641</a>
                </div>
                <a class="footer__mail" href="mailto: kontakt@existagency.pl">kontakt@existagency.pl</a>
            </div>
            <div class="footer__menu">
                <a href="#">Branding/rebranding</a>
                <a href="#">Strona firmowa</a>
                <a href="#">Strona firmowa PRO</a>
                <a href="#">Sklep internetowy</a>
            </div>
            <div class="footer__redirections">
                <a href="#">Wycena</a>
                <a href="#">Obsługa strony</a>
                <a href="#">Marketing</a>
                <a href="#">Social media</a>
            </div>
            <div class="footer__partners">
                <a href="#">Oferteo.pl</a>
                <a href="#">lh.pl</a>
            </div>
            <div class="footer__social">
                <a href="#"><img class="footer__icon" src="<?= get_template_directory_uri() . "/images/fb.png"; ?>"
                        alt="Sprawdź nas na facebooku"></a>
            </div>
        </div>
    </div>

</section>