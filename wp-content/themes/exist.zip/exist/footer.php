<?php

?>

<?php wp_footer(); ?>


<?php

if ($_SERVER['HTTP_HOST'] == "localhost") {
	echo '<script src="//localhost:35729/livereload.js"></script>';
}

?>

</body>

</html>