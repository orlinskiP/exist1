<?php

get_header();
?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

		<?php
		while ( have_posts() ) :

			the_post();
			get_template_part( 'template-parts/content', 'page' );
		endwhile; 

		if (get_field('footer_modules_off') != 1) {

			$id 			= 	get_field('footer_page_modules', 'option');
			$the_query 		= 	new WP_Query('page_id=' . $id);

			if ($id != "") {

				while ($the_query->have_posts()) : $the_query->the_post();

					get_template_part('template-parts/content', 'page');

				endwhile;

				wp_reset_query();
			}
		}
		?>
		</main>
	</div>

<?php

get_footer();
